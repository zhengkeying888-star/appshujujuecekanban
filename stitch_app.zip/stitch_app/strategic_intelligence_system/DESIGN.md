---
name: Strategic Intelligence System
colors:
  surface: '#081425'
  surface-dim: '#081425'
  surface-bright: '#2f3a4c'
  surface-container-lowest: '#040e1f'
  surface-container-low: '#111c2d'
  surface-container: '#152031'
  surface-container-high: '#1f2a3c'
  surface-container-highest: '#2a3548'
  on-surface: '#d8e3fb'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#d8e3fb'
  inverse-on-surface: '#263143'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#ffb786'
  on-tertiary: '#502400'
  tertiary-container: '#df7412'
  on-tertiary-container: '#461f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#081425'
  on-background: '#d8e3fb'
  surface-variant: '#2a3548'
typography:
  metric-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-padding: 24px
  gutter: 16px
  nav-height: 64px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
This design system is engineered for high-stakes business intelligence and executive decision-making. It adopts a **Corporate / Modern** aesthetic with **Glassmorphism** accents to convey a sense of depth, precision, and technological sophistication.

The visual language balances the density of complex data with a clean, structured layout. It aims to evoke feelings of authority, clarity, and forward-looking strategy. High-contrast typography and subtle luminosity effects are used to draw attention to critical KPIs, while the deep blue-grey foundation reduces cognitive load during extended analytical sessions.

## Colors
The palette is built upon a deep "Slate" foundation to create a premium, tech-focused environment. 

- **Foundation:** The background utilizes `#0f172a`, providing a high-contrast base for the lighter `#1e293b` surfaces.
- **Accents:** A vibrant blue-to-purple gradient serves as the primary brand identifier, used sparingly for primary actions and data highlights.
- **Feedback:** Success, danger, and warning colors are saturated to ensure visibility against the dark background, supplemented by soft glow effects (`0.2` opacity) to indicate active states or critical alerts.
- **Hierarchy:** Typography uses three distinct shades of grey-white to establish a clear information hierarchy.

## Typography
The system utilizes **Inter** for all alphanumeric characters to ensure maximum legibility in data-heavy contexts. For Chinese characters, **Noto Sans SC** is the standard, maintaining a humanist and modern feel.

- **Metrics:** A specialized `metric-lg` style is defined for high-level dashboard figures, using a Bold weight and tighter letter-spacing.
- **Hierarchy:** Use `label-sm` in all-caps for category headers or metadata. 
- **Readability:** Body text maintains a generous line height to prevent visual fatigue in reports and data descriptions.

## Layout & Spacing
The layout follows a **Fixed Grid** approach for the main dashboard content to ensure data visualization consistency, while the container itself can scale fluidly across ultra-wide monitors.

- **Grid:** A 12-column system with a 16px gutter.
- **Margins:** Standard page margins are set to 24px.
- **Navigation:** The top navigation bar is fixed at 64px, utilizing a frosted glass effect to maintain context of the content scrolling beneath it.
- **Density:** Spacing units are based on an 8px scale, allowing for precise alignment of dense data tables and charts.

## Elevation & Depth
Depth is created through a combination of **Tonal Layering** and **Glassmorphism**.

- **Surfaces:** Level 0 is the background. Level 1 consists of card surfaces (`#1e293b`). Level 2 (hover/active states) uses `#334155`.
- **Shadows:** Cards use a deep, large-radius shadow: `0 4px 24px rgba(0,0,0,0.3)`. This provides a distinct lift from the dark background without looking "muddy."
- **Borders:** Subtle low-contrast outlines (`rgba(148,163,184,0.12)`) define the edges of surfaces, replacing heavy shadows for a cleaner, more technical look.
- **Glass Effects:** Navigation and overlays use a `backdrop-filter: blur(12px)` with an `80%` opacity fill to create a premium, translucent aesthetic.

## Shapes
The shape language is refined and approachable yet professional.

- **Cards:** All primary containers and dashboard cards use a **16px (1rem)** corner radius.
- **Small Elements:** Buttons, input fields, and tags use a **8px (0.5rem)** radius.
- **Interactive States:** Hovering over list items or interactive table rows should trigger a subtle 4px rounded background highlight.

## Components
Consistent component styling ensures the dashboard feels unified and high-end.

- **KPI Cards:** Feature the `metric-lg` typography. Include a small sparkline chart and a status indicator (success/danger) with a soft outer glow.
- **Buttons:** Primary buttons use the `3b82f6` to `8b5cf6` gradient. Ghost buttons use the standard border and `text-secondary` color.
- **Input Fields:** Darker than the card surface (`#0f172a`) with a 1px border. Focus state should trigger a `primary_color` glow.
- **Data Tables:** Use `label-sm` for headers with 40% opacity. Rows should have a subtle separator and a `#334155` background on hover.
- **Charts:** Use the brand gradient for primary data series. Grid lines in charts should match the system border color (`rgba(148,163,184,0.12)`).
- **Navigation Bar:** 64px height, fixed to top. Includes a blurred background and a bottom border for definition.